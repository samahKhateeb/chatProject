package com.example.exampleproject.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.exampleproject.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class EmailAndPassword extends AppCompatActivity {


    private final String TAG = "EmailAndPassword";
    private EditText edtEmail;
    private EditText edtPassword;
    Button btnGuest;
    Button btnContinue;
    FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_and_password);


        edtEmail = findViewById(R.id.edEmail);
        edtPassword = findViewById(R.id.edpassword);
        btnGuest = findViewById(R.id.btnGuest);
        btnContinue = findViewById(R.id.btnContinue);


    }

    public void guestLogin(View view) {
        auth.signInAnonymously().addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {

                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            auth.signOut();
                        }
                    }, 30 * 60 * 1000);
                    //يجب اعادةارجاعه لنقطة البدايه((يجب تصليحه)todo

                    Intent intent = new Intent(EmailAndPassword.this, Avatar.class);

                    startActivity(intent);

                    finish();
                } else {
                    Toast.makeText(EmailAndPassword.this, "no internet conection", Toast.LENGTH_LONG).show();
                }
            }
        });

    }


    //تفعيل زر الاستمرار
    public void continueLogin(View view) {
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Log.d(TAG, "Email registration has been successful ");
                    FirebaseUser user = auth.getCurrentUser();
                    Toast.makeText(EmailAndPassword.this, "welcome " + user.getDisplayName(), Toast.LENGTH_SHORT).show();
                    gotoAvatarActivity();
                } else {
                    Log.d(TAG, "Email registration failed" + task.getException());
                    Toast.makeText(EmailAndPassword.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        });

    }

    private void gotoAvatarActivity() {


        Intent intent = new Intent(EmailAndPassword.this, Avatar.class);

        startActivity(intent);


    }
}


