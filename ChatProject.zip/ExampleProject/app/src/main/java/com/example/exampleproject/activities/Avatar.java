package com.example.exampleproject.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.exampleproject.classes.AvatarUr;
import com.example.exampleproject.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class Avatar extends AppCompatActivity {
    TextView tvNickName;
    ImageView imgAdd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avatar);
        tvNickName = findViewById(R.id.tvNickName);
        imgAdd = findViewById(R.id.imgAdd);
    }


    public void saveUserName(View view) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("userName");
        myRef.setValue(tvNickName.getText().toString());


    }

    public void chooseIcon(View view) {
        if (tvNickName.getText().toString().length() > 3) {
            Intent intent = new Intent(Avatar.this, AvatarList.class);
            intent.putExtra("MyName", tvNickName.getText().toString());
            startActivity(intent);
            finish();
        }
    }

    public static class AvatarAdapter extends FirebaseRecyclerAdapter {
        private static final int VIEW_TYPE_IMAGE = 2;
        final String TAG = "AvatarAdapter";
        private static final int VIEW_TYPE_TEXT = 1;
        final String ANONYMOUS = "anonymous";
        public String selectedAvatarUrl = "";

        private FirebaseRecyclerOptions<AvatarUr> options;

        public AvatarAdapter(FirebaseRecyclerOptions<AvatarUr> options) {
            super(options);

            this.options = options;
        }

        @Override
        protected void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position, @NonNull Object model) {
            ((Avatar.AvatarAdapter.AvatarViewHolder) holder).bind((AvatarUr) model);
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            RecyclerView.ViewHolder viewHolder;


            View view = inflater.inflate(R.layout.icons_list, parent, false);
            viewHolder = new AvatarViewHolder(view);

            return viewHolder;
        }


        private class AvatarViewHolder extends RecyclerView.ViewHolder {
            ImageView avatarIcon;
            TextView tvUrlStr;

            public AvatarViewHolder(View view) {
                super(view);
                this.avatarIcon = view.findViewById(R.id.avatarIcon);
                this.tvUrlStr = view.findViewById(R.id.tvUrlStr);
            }

            public void bind(AvatarUr item) {
                loadImageIntoView(avatarIcon, item.getUrlStr());
                tvUrlStr.setText(item.getTitle());
                avatarIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        selectedAvatarUrl = item.getUrlStr();
                        Log.d(TAG, "onClick: selected " + item.getUrlStr());
                    }
                });
            }


        }

        private void loadImageIntoView(ImageView view, String url) {
            if (url.startsWith("gs://")) {
                StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(url);
                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(@NonNull Uri uri) {
                        String downloadUrl = uri.toString();
                        Glide.with(view.getContext()).load(downloadUrl).into(view);
                        Log.d(TAG, "Getting download url was successful.");
                    }
                }).addOnFailureListener(new OnFailureListener() {

                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "Getting download url was not successful.", e);
                    }
                });
            } else {
                Glide.with(view.getContext()).load(url).into(view);
            }
        }
    }}


