package com.example.exampleproject.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.exampleproject.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class Search extends AppCompatActivity {
    private static final String TAG = "status";

    FirebaseAuth.AuthStateListener mAuthListener;
    CircleImageView logo;
    TextView myName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        myName = findViewById(R.id.myName);

        logo =findViewById(R.id.logo);
        logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Search.this, Dialog.class);
                startActivity(intent);
                finish();
            }
        });

    }
  //save the name and profile photo
    @Override
    protected void onResume() {
        super.onResume();
        updateUi();
    }

    private void updateUi() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            Toast.makeText(Search.this, "user name:" + user.getDisplayName(), Toast.LENGTH_SHORT).show();
            Toast.makeText(Search.this, "user photo:" + user.getPhotoUrl(), Toast.LENGTH_SHORT).show();

            myName.setText(user.getDisplayName());
            //Glide.with(status.this).load(user.getPhotoUrl()).override(150, 150).into(logo);
            loadImageIntoView(logo, user.getPhotoUrl().toString());
        }
    }

    private void loadImageIntoView(ImageView view, String url) {
        if (url.startsWith("gs://")) {
            StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(url);
            storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(@NonNull Uri uri) {
                    String downloadUrl = uri.toString();
                    Glide.with(view.getContext())
                            .load(downloadUrl)
                            .into(view);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d(TAG, "Getting download url was not successful.", e);
                }
            });
        } else {
            Glide.with(view.getContext()).load(url).into(view);
        }
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user != null) {
                    Intent intent = new Intent(Search.this, Dialog.class);
                    startActivity(intent);
                    finish();
                }

            }



        };
    }
}