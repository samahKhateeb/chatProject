package com.example.exampleproject.adapters;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class MessageViewHolder extends RecyclerView.ViewHolder {
    public MessageViewHolder(View itemView) {
        super(itemView);
    }
}
