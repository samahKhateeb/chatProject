package com.example.exampleproject.activities;

import static com.example.exampleproject.adapters.MessageAdapter.loadImageIntoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.exampleproject.classes.Message;
import com.example.exampleproject.adapters.MessageAdapter;
import com.example.exampleproject.R;
import com.example.exampleproject.classes.ScrollToButtomObserver;
import com.example.exampleproject.classes.SendButtonObserver;
import com.example.exampleproject.databinding.ActivityDialogBinding;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class Dialog extends AppCompatActivity {

   final String TAG = "MyChat:" + getClass().getSimpleName();
   final String MESSAGES_CHILD = "messages";
   final String ANONYMOUS = "anonymous";
   final int REQUEST_IMAGE = 2;
   final int REQUEST_IMAGE_FOR_PROFILE = 3;
   final String LOADING_IMAGE_URL = "https://www.google.com/images/spin-32.gif";


   private ActivityDialogBinding binding;
   private FirebaseAuth auth;
   private FirebaseDatabase db;
   DatabaseReference messagesRef;
   private MessageAdapter adapter;
   private LinearLayoutManager manager;
   private MediaRecorder recorder;
   private String outputFile;


   @SuppressLint("WrongConstant")
   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      // inflate and load layout from binding
      binding = ActivityDialogBinding.inflate(getLayoutInflater());
      setContentView(binding.getRoot());


      binding.phone.setOnClickListener(new View.OnClickListener() {

         @Override
         public void onClick(View v) {
            Intent intent = new Intent(Intent.ACTION_CALL);
         }
      });



      outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/AudioRecording.3gp";


      recorder = new MediaRecorder();


      auth = FirebaseAuth.getInstance();
      db = FirebaseDatabase.getInstance();
      messagesRef = db.getReference().child(MESSAGES_CHILD);

      FirebaseRecyclerOptions<Message> options = new FirebaseRecyclerOptions.Builder<Message>().setQuery(messagesRef, Message.class).build();
      adapter = new MessageAdapter(options, getUserName());
      binding.progressBar.setVisibility(ProgressBar.INVISIBLE);
      manager = new LinearLayoutManager(this);
      manager.setStackFromEnd(true);
      binding.messageRecyclerView.setLayoutManager(manager);
      binding.messageRecyclerView.setAdapter(adapter);

      binding.edMessage.addTextChangedListener(new SendButtonObserver(binding.sendButton));

      adapter.registerAdapterDataObserver(new ScrollToButtomObserver(binding.messageRecyclerView, adapter, manager));

      binding.sendButton.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
            String text = binding.edMessage.getText().toString();
            Message newMessage = new Message(text, getUserName(), getPhotoUrl(), null);

            messagesRef.push().setValue(newMessage);
            binding.edMessage.setText("");

         }
      });

      binding.back.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
            Intent i = new Intent(Dialog.this, Search.class);
            startActivity(i);
            finish();
         }
      });




      binding.add.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, REQUEST_IMAGE);
         }
      });


      binding.mic.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
            try {
               binding.mic2.setEnabled(false);
               binding.play1.setEnabled(false);
               recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
               recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
               recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
               recorder.setOutputFile(outputFile);
               recorder.prepare();
               recorder.start();
               binding.play1.setEnabled(false);
               binding.mic2.setEnabled(true);
               Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_LONG).show();

            } catch (Exception e) {
               e.printStackTrace();
            }}


      });

      binding.mic2.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
            recorder.stop();
            recorder.release();
            recorder = null;
            binding.mic.setEnabled(true);
            binding.mic2.setEnabled(false);
            binding.play1.setEnabled(true);
            Toast.makeText(getApplicationContext(), "Audio Recorder stopped", Toast.LENGTH_LONG).show();
         }
      });
      binding.play1.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
            MediaPlayer mediaPlayer = new MediaPlayer();
            try {
               mediaPlayer.setDataSource(outputFile);
               mediaPlayer.prepare();
               mediaPlayer.start();
               Toast.makeText(getApplicationContext(), "Playing Audio", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
               // make something
            }
         }
      });
   }

   @Override
   protected void onStart() {
      super.onStart();

      if (auth.getCurrentUser() == null) {
         Log.d(TAG, "onCreate: inValid user");
         // Not signed in, launch the Sign In activity
         startActivity(new Intent(this, Search.class));
         finish();
         return;
      }

      Log.d(TAG, "onCreate: valid user");

      //  Toast.makeText(Dialog.this, "started", Toast.LENGTH_SHORT).show();
      adapter.startListening();
   }

   @Override
   protected void onStop() {
      super.onStop();
      // Toast.makeText(Dialog.this, "stoped", Toast.LENGTH_SHORT).show();
      adapter.stopListening();
   }

   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
      getMenuInflater().inflate(R.menu.main_menu, menu);
      return true;
   }

   @Override
   public boolean onOptionsItemSelected(@NonNull MenuItem item) {
      switch (item.getItemId()) {
         case R.id.sign_out_menu:
            signout();
            return true;
         case R.id.icon_group:
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, REQUEST_IMAGE_FOR_PROFILE);
            return true;
      }

      return super.onOptionsItemSelected(item);
   }

   @Override
   protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
      super.onActivityResult(requestCode, resultCode, data);
      switch (requestCode) {
         case REQUEST_IMAGE:
            if (resultCode == RESULT_OK && data != null) {
               Uri uri = data.getData();
               Log.d(TAG, "Uri: " + uri.toString());
               FirebaseUser user = auth.getCurrentUser();
               Message tempMessage = new Message(null, getUserName(), getPhotoUrl(), LOADING_IMAGE_URL);
               messagesRef.push()
                       .setValue(tempMessage, new DatabaseReference.CompletionListener() {
                          @Override
                          public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                             if (databaseError != null) {
                                Log.d(TAG, "Unable to write message to database.", (Throwable) databaseError.toException());
                             } else {
                                String key = databaseReference.getKey();
                                FirebaseStorage storageReference = FirebaseStorage.getInstance();
                                StorageReference userStorageRef = storageReference.getReference(user.getUid()).child(key).child(uri.getLastPathSegment());
                                putImageInStorage(userStorageRef, uri, key);
                             }
                          }
                       });
            }
            break;
         case REQUEST_IMAGE_FOR_PROFILE:
            if (resultCode == RESULT_OK && data != null) {
               Uri uri = data.getData();
               FirebaseUser user = auth.getCurrentUser();
               FirebaseStorage storageReference = FirebaseStorage.getInstance();
               StorageReference userStorageRef = storageReference.getReference(user.getUid());
               userStorageRef.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                  @Override
                  public void onSuccess(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                     taskSnapshot.getMetadata().getReference().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(@NonNull Uri uri) {
                           Toast.makeText(Dialog.this,"uploaded",Toast.LENGTH_SHORT).show();
                           updateUserProfilePicture(uri);
                        }
                     }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                           Toast.makeText(Dialog.this,"error upload",Toast.LENGTH_SHORT).show();
                           e.printStackTrace();
                        }
                     });
                  }
               });
            } else {
            }
            break;
      }
   }

   private void updateUserProfilePicture(final Uri uri) {
      Log.d(TAG, "updateUserProfilePicture: uri=" + uri.toString());
      UserProfileChangeRequest profileChangeRequest = new UserProfileChangeRequest.Builder()
              .setPhotoUri(uri)
              .build();

      auth.getCurrentUser().updateProfile(profileChangeRequest)
              .addOnCompleteListener(new OnCompleteListener<Void>() {
                 @Override
                 public void onComplete(@NonNull Task<Void> task) {
                    Log.d(TAG, "onComplete: Profile image has changed successfully");
                 }
              });
   }

   private void putImageInStorage(StorageReference storageReference, Uri uri, String key) {
      storageReference.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
         @Override
         public void onSuccess(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
            taskSnapshot.getMetadata().getReference().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
               @Override
               public void onSuccess(@NonNull Uri uri) {
                  Message message = new Message(null, getUserName(), getPhotoUrl(), uri.toString());
                  messagesRef.child(key).setValue(message);
               }
            });
         }
      }).addOnFailureListener(new OnFailureListener() {
         @Override
         public void onFailure(@NonNull Exception e) {
            Log.d(TAG, "" + e.getMessage());
            // TODO - Remove the message from realtime database, by key
         }
      });
   }

   private void signout() {
      auth.signOut();
      startActivity(new Intent(this, AvatarList.class));
      finish();
   }

   private String getPhotoUrl() {
      Uri url = FirebaseAuth.getInstance().getCurrentUser().getPhotoUrl();
      return url == null ? null : url.toString();
   }

   private String getUserName() {
      FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
      return user == null ? ANONYMOUS : user.getDisplayName();
   }



   public void openCamera(View view) {
      Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      startActivityForResult(intent,999);

   }


   public void startRecord(View view) {
      Toast.makeText(this, "start", Toast.LENGTH_SHORT).show();
      try {
         binding.mic2.setEnabled(false);
         binding.play1.setEnabled(false);
         recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
         recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
         recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
         recorder.setOutputFile(outputFile);
         recorder.prepare();
         recorder.start();
         binding.play1.setEnabled(false);
         binding.mic2.setEnabled(true);
         Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_LONG).show();

      } catch (Exception e) {
         e.printStackTrace();

      } }@Override
   protected void onResume() {
      super.onResume();
      updateUi();
   }

   private void updateUi() {
      FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
      if (user != null) {
         Toast.makeText(Dialog.this, "user name:" + user.getDisplayName(), Toast.LENGTH_SHORT).show();
         Toast.makeText(Dialog.this, "user photo:" + user.getPhotoUrl(), Toast.LENGTH_SHORT).show();

         binding.name1.setText(user.getDisplayName());
         //Glide.with(status.this).load(user.getPhotoUrl()).override(150, 150).into(logo);
         loadImageIntoView(binding.prof, user.getPhotoUrl().toString());
      }

   }}











