package com.example.exampleproject.classes;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ImageView;

import androidx.appcompat.widget.AppCompatImageView;

import com.example.exampleproject.R;

public class SendButtonObserver implements TextWatcher {
    private ImageView sendButton;

    public SendButtonObserver(AppCompatImageView sendButton) {
        this.sendButton = sendButton;
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if (charSequence.length()>0) {
            sendButton.setEnabled(true);
            sendButton.setImageResource(R.drawable.ic_baseline_send1);
        } else {
            sendButton.setEnabled(false);
            sendButton.setImageResource(R.drawable.ic_baseline_send_24);
        }
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }
}
