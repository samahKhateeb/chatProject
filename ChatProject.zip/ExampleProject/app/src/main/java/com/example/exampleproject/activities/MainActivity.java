package com.example.exampleproject.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.example.exampleproject.R;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity {
    private static final String TAG="MainActivity";
    ImageView imgHome;
    ProgressBar pbTimer;
    private FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgHome = findViewById(R.id.imgHome);
        pbTimer = findViewById(R.id.pbTimer);
        auth = FirebaseAuth.getInstance();
    }
    @Override
    protected void onStart() {
        super.onStart();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, Welcome.class);
                startActivity(intent);

            }


        }, 3000);


        if (auth.getCurrentUser() == null) {
            Log.d(TAG, "onCreate: no valid user, login to continue");

        } else {
            Log.d(TAG, "onCreate: welcome ");
            Intent intent = new Intent(this, Dialog.class);
            startActivity(intent);
            finish();
        }

    }
}



