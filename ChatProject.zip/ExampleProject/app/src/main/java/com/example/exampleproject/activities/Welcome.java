package com.example.exampleproject.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.exampleproject.R;
import com.google.firebase.database.FirebaseDatabase;

public class Welcome extends AppCompatActivity {
    ImageView imgTalk;
    TextView tvWelcome;
    Button btnSignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);


        imgTalk = findViewById(R.id.imgTalk);
        tvWelcome = findViewById(R.id.tvWelcome);
        btnSignIn = findViewById(R.id.btnSignIn);

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Welcome.this, EmailAndPassword.class);
                startActivity(intent);
                finish();
            }
        });

        FirebaseDatabase.getInstance().getReference().push().setValue("test");
    }


}


