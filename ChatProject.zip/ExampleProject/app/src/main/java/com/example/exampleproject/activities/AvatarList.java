package com.example.exampleproject.activities;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.exampleproject.classes.AvatarUr;
import com.example.exampleproject.R;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class AvatarList extends AppCompatActivity {
    RecyclerView rcAvatars;
    Button btnAdd;

    FirebaseRecyclerOptions<AvatarUr> options;
    private Query avatarsRef;
    Avatar.AvatarAdapter adapter;
    String myName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avatar_list);
        myName=getIntent().getStringExtra("MyName");

        rcAvatars = findViewById(R.id.rvAvatars);
        btnAdd =findViewById(R.id.btnAdd);
        avatarsRef = FirebaseDatabase.getInstance().getReference().child("photos");
        options = new FirebaseRecyclerOptions.Builder<AvatarUr>().setQuery(avatarsRef,AvatarUr.class).build();
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rcAvatars.setLayoutManager(layoutManager);
        adapter = new Avatar.AvatarAdapter(options);
        rcAvatars.setAdapter(adapter);
        adapter.startListening();
        //لما بدي اضيف صوره بحطو بالستوريج وباخد الكيشور بسجلو بهاد الكود مره بشغله وبرجع بطفيه لما اطلع
        /*
        avatarsRef.getRef().push().setValue(new AvatarUr("lady","gs://mytalkbox-add8f.appspot.com/lady_portrait_avatar_template_cartoon_character_sketch_6849753.jpg")).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){

                } else {
                    Log.d(AvatarList.class.getSimpleName(), "onComplete: ok");

                }
            }
        });*/

    }


    public void Add (View view) {


        if (AvatarList.this.adapter.selectedAvatarUrl.length() > 0) {
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

            UserProfileChangeRequest profileIcon = new UserProfileChangeRequest.Builder().
                    setPhotoUri(Uri.parse(adapter.selectedAvatarUrl)).setDisplayName(myName).build();
// https://firebasestorage.googleapis.com/v0/b/mytalkbox-add8f.appspot.com/o/images.jpg?alt=media&token=ef2ebf07-0e90-40ee-a35f-5a5d7201f558
            user.updateProfile(profileIcon).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Log.d(TAG, "user profile update.");

                        Intent intent = new Intent(AvatarList.this, Search.class);

                        startActivity(intent);
                        finish();
                    } else {
                        task.getException().printStackTrace();
                        Log.d(TAG, "onComplete: "+task.getException().getMessage());
                    }
                }
            });


        }


    }


}
