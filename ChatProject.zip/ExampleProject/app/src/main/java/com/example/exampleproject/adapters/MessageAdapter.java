package com.example.exampleproject.adapters;

import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.exampleproject.R;
import com.example.exampleproject.classes.Message;
import com.example.exampleproject.databinding.ActivityMessageBinding;
import com.example.exampleproject.databinding.ChatItemLeftBinding;
import com.example.exampleproject.databinding.ChatItemRightBinding;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class MessageAdapter extends FirebaseRecyclerAdapter {
    private static final int VIEW_TYPE_IMAGE = 2;
    final String TAG = "MyChat:" + getClass().getSimpleName();
    private static final int VIEW_TYPE_TEXT = 1;
    final String ANONYMOUS = "anonymous";
    public final int MSG_TYPE_LIFT = 3;
    public final int MSG_TYPE_RIGHT = 4;
    FirebaseUser fUser;
    private FirebaseRecyclerOptions<Message> options;
    private String currentUserName;


    public MessageAdapter(FirebaseRecyclerOptions<Message> options, String currentUserName) {
        super(options);
        this.options = options;
        this.currentUserName = currentUserName;

    }


    @Override
    protected void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position, @NonNull Object model) {
        if (getItemViewType(position) == MSG_TYPE_RIGHT) {
            ((MessageAdapter.MessageRightViewHoler) holder).bind((Message) model);
        } else {
            ((MessageAdapter.MessageLeftViewHoler) holder).bind((Message) model);
        }
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view;


        switch (viewType) {

            case MSG_TYPE_RIGHT:
                view = inflater.inflate(R.layout.chat_item_right, parent, false);
                ChatItemRightBinding bindingRight = ChatItemRightBinding.bind(view);
                viewHolder = new MessageRightViewHoler(bindingRight);
                break;
            default: //case MSG_TYPE_LIFT:
                view = inflater.inflate(R.layout.chat_item_left, parent, false);
                ChatItemLeftBinding bindingLift = ChatItemLeftBinding.bind(view);
                viewHolder = new MessageLeftViewHoler(bindingLift);
                break;
        }

        return viewHolder;

    }

    @Override
    public int getItemViewType(int position) {
        Message msg = (Message) getItem(position);
        if (msg.getName().equals(FirebaseAuth.getInstance().getCurrentUser().getDisplayName())) {
            return MSG_TYPE_LIFT;
        }
        return MSG_TYPE_RIGHT;
    }

    @Override
    public int getItemCount() {
        return options.getSnapshots().size();
    }

    private static class MessageViewHolder extends RecyclerView.ViewHolder {
        private ActivityMessageBinding binding;
        private String userName;
        private TextView textView;

        public MessageViewHolder(ActivityMessageBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        private int setTextColor(String userName, TextView textView) {
            this.userName = userName;
            this.textView = textView;

            return 0;
        }

        public void bind(Message item) {


            String photoUrl = item.getImageUrl();
            String userPhotoUrl = item.getPhotoUrl();

            if (item.getText() != null) {
                binding.messengerTextView.setText(item.getText());
                //setTextColor(item.getName(), binding.messengerTextView);
            }

            if (photoUrl != null) {
                loadImageIntoView(binding.messageImageView, photoUrl);
                binding.messageImageView.setVisibility(View.VISIBLE);
            } else {
                binding.messageImageView.setVisibility(View.GONE);
            }

            loadImageIntoView(binding.messengerImageView, userPhotoUrl);


        }

    }


    public static void loadImageIntoView(ImageView view, String url) {
        if (url.startsWith("gs://")) {
            StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(url);
            storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(@NonNull Uri uri) {
                    String downloadUrl = uri.toString();
                    Glide.with(view.getContext())
                            .load(downloadUrl)
                            .into(view);
                }
            }).addOnFailureListener(new OnFailureListener() {
                public String TAG;

                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.d(TAG, "Getting download url was not successful.", e);
                }
            });
        } else {
            Glide.with(view.getContext()).load(url).into(view);
        }
    }

    public class MessageLeftViewHoler extends RecyclerView.ViewHolder {
        private ChatItemLeftBinding binding;

        public MessageLeftViewHoler(ChatItemLeftBinding binding) {
            super((View) binding.getRoot());
            this.binding = binding;
        }

        public void bind(Message item) {
            binding.showMessage1.setText(item.getText());
            loadImageIntoView(binding.sora, item.getPhotoUrl());
        }
    }

    private class MessageRightViewHoler extends RecyclerView.ViewHolder {
        private ChatItemRightBinding binding;

        public MessageRightViewHoler(ChatItemRightBinding bindingRight) {
            super((View) bindingRight.getRoot());
            this.binding = bindingRight;
        }

        public void bind(Message item) {
            if (item.getText()!=null) {
                binding.showMessage.setText(item.getText());
            }

        }
    }

    private class ImageMessageViewHolder extends com.example.exampleproject.adapters.MessageViewHolder {
        private ActivityMessageBinding binding;

        public ImageMessageViewHolder(ActivityMessageBinding binding) {
            super((View) binding.getRoot());
            this.binding = binding;
        }

        public void bind(Message item) {
            loadImageIntoView(binding.messageImageView, item.getImageUrl());
            binding.messengerTextView.setText(item.getName() == null ? ANONYMOUS : item.getName());
            if (item.getPhotoUrl() != null) {
                loadImageIntoView(binding.messengerImageView, item.getPhotoUrl());
            } else {
                binding.messengerImageView.setImageResource(R.drawable.ic_logo);
            }
        }


        private void loadImageIntoView(ImageView view, String url) {
            if (url.startsWith("gs://")) {
                StorageReference storageReference = FirebaseStorage.getInstance().getReferenceFromUrl(url);
                storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(@NonNull Uri uri) {
                        String downloadUrl = uri.toString();
                        Glide.with(view.getContext())
                                .load(downloadUrl)
                                .into(view);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d(TAG, "Getting download url was not successful.", e);
                    }
                });
            } else {
                Glide.with(view.getContext()).load(url).into(view);
            }
        }


    }


}

