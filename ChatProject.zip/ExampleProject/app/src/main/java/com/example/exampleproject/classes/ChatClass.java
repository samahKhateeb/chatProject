package com.example.exampleproject.classes;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.exampleproject.R;

public interface ChatClass {
     class ChatViewHolder extends RecyclerView.ViewHolder {
        public TextView tvName;
        public TextView tvMessage;
        public TextView tvTime;
        public TextView tvUnread;
        public ImageView imgIcon;

        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvMessage = itemView.findViewById(R.id.tvMessage);
            tvTime = itemView.findViewById(R.id.tvTime);
            tvUnread = itemView.findViewById(R.id.tvUnread);
            imgIcon = itemView.findViewById(R.id.avatarIcon);
        }


    }

}