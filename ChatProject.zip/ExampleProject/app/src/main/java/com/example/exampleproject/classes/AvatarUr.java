package com.example.exampleproject.classes;

public class AvatarUr {
    private String title;
    private  String urlStr;

    public AvatarUr() {
    }

    public AvatarUr(String title, String urlStr) {
        this.title = title;
        this.urlStr = urlStr;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrlStr() {
        return urlStr;
    }

    public void setUrlStr(String urlStr) {
        this.urlStr = urlStr;
    }

    @Override
    public String toString() {
        return "AvatarUr{" +
                "title='" + title + '\'' +
                ", urlStr='" + urlStr + '\'' +
                '}';
    }
}
