package com.example.exampleproject.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.exampleproject.classes.ChatClass;
import com.example.exampleproject.R;
import com.example.exampleproject.classes.Chat;

import java.util.ArrayList;


class ChatAdapter extends RecyclerView.Adapter<ChatClass.ChatViewHolder> implements ChatClass {
    private final ArrayList<Chat> chats;//private static  final int VIEW_TYPE_IMAGE=2


    public ChatAdapter(ArrayList<Chat> chats) {

        super();
        this.chats = chats;

    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View chatView = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_adapter, parent, false);

        return new ChatViewHolder(chatView);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        Chat currentChat = chats.get(position);
        holder.tvName.setText(currentChat.getName());
        holder.tvMessage.setText(currentChat.getMessage());
        holder.tvTime.setText((CharSequence) currentChat.getTime());
        holder.imgIcon.setImageResource(

                holder.tvName.getResources().getIdentifier(String.valueOf(currentChat.getIcon()),
                        "drawable",
                        holder.tvName.getContext().getPackageName())

        );

    }

    @Override
    public int getItemCount() {

        return chats.size();
    }


}




