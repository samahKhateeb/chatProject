package com.example.exampleproject.classes;

import android.net.Uri;

import java.util.ArrayList;
import java.util.Date;

public class Chat {
    private String name;
    private String message;
    private Date time;
    private Uri icon;
    private int unread;

    public Chat(String name, String message, Date time, Uri icon, int unread) {
        super();
        this.name = name;
        this.message = message;
        this.time = time;
        this.icon = icon;
        this.unread = unread;
    }



    public Chat(Date time, Uri icon, String name, String message) {

        this.time = time;
        this.icon = icon;
        this.name = name;
        this.message = message;
    }

    public Chat(ArrayList<Chat> chats) {

    }

    public Chat(String name, String hello, String s, Uri icon, int i) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Uri getIcon() {
        return icon;
    }

    public void setIcon(Uri icon) {
        this.icon = icon;
    }

    public int getUnread() {
        return unread;
    }

    public void setUnread(int unread) {
        this.unread = unread;
    }






}




